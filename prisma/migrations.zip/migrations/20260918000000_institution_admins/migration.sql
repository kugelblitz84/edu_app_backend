CREATE TABLE "institution_admins" (
  "institution_id" UUID NOT NULL,
  "user_id" UUID NOT NULL,

  CONSTRAINT "institution_admins_pkey" PRIMARY KEY ("institution_id", "user_id")
);

CREATE INDEX "institution_admins_user_id_idx"
  ON "institution_admins"("user_id");

ALTER TABLE "institution_admins"
  ADD CONSTRAINT "institution_admins_institution_id_fkey"
  FOREIGN KEY ("institution_id") REFERENCES "institutions"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "institution_admins"
  ADD CONSTRAINT "institution_admins_user_id_fkey"
  FOREIGN KEY ("user_id") REFERENCES "users"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;